# Resume Test Files

The bundled `dataset/` is certificate-only — there's no resume dataset
in this project (nothing to download or generate elsewhere). These 8
files were generated specifically to test every code path in the
Resume Analysis page, including its known limitations. Upload each one
on the **Resume Analysis** page and compare against the expected result
below.

| File | Tests | Expected result |
|---|---|---|
| `01_clean_resume_genuine_cert.pdf` | Normal case, text-based PDF, references a **genuine** certificate | All fields extracted cleanly. Certificate ID `CERT-P89UZFK8` detected → clicking "Verify this ID" returns **VERIFIED**. |
| `02_clean_resume_image.png` | Image upload instead of PDF (OCR path, not pdfplumber) | Same clean extraction, via Tesseract instead of pdfplumber. Cert `CERT-IBLJH75L` → **VERIFIED**. |
| `03_resume_with_tampered_cert.pdf` | Resume references a certificate that exists but was **tampered** | Resume parses fine. Clicking "Verify this ID" on `CERT-B4GH2M5Z` returns **SUSPICIOUS** (issue date mismatch). |
| `04_resume_with_fake_cert_id.pdf` | Resume references a certificate ID that **doesn't exist** anywhere | Parses fine, ID `CERT-ZZZZZZZZ` detected, but verification reports "not found in issuer database." |
| `05_resume_us_phone_number.pdf` | Non-Indian phone format (`+1 (415) 555-0199`) | **Phone comes back `None`.** This exposes a real limitation: the phone regex (`[6-9]\d{9}`) is India-only. |
| `06_resume_misleading_header.pdf` | Resume opens with "CURRICULUM VITAE" before the actual name | **Name comes back "CURRICULUM VITAE"**, not "Priya Nair." Exposes the "name = first line" limitation. |
| `07_resume_multiple_certs.pdf` | Two certificate IDs in one resume — one genuine, one fake | Both `CERT-5C34DXTA` and `CERT-QQQQQQQQ` are detected; the first verifies, the second doesn't resolve. |
| `08_scanned_resume_no_text_layer.pdf` | A PDF with **no text layer at all** (just an embedded image) | Tests the OCR-fallback path in `resume_service.py` (pdfplumber finds no text → renders the page as an image → OCRs it). Should still extract everything correctly. |

## Why #5 and #6 are included deliberately

These two are not bugs to "fix by accident" — they're here so you can
demonstrate, in a review, that you understand the system's real limits
rather than just showing the happy path. See the "Known limitations"
section in the main README.md for the underlying reasons and what a
more robust fix would look like (locale-flexible phone regex, NLP-based
name extraction instead of "first line").
